﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class MoveNode_DamageTarget : CombatMoveNode
{
	public int damage = 1;
	public CombatManager.eDamageMultiplier multiplier = CombatManager.eDamageMultiplier.Doubled;
	public CombatManager.eDamageType type = CombatManager.eDamageType.Physical;
	public bool timedHit = false;

	public override void Fire (FireArguments args)
	{
		switch (args.targetType)
		{
		case FireArguments.eTargetType.Single:
			CombatManager.Singleton.AddDamage(new CombatManager.sDamage(damage, type, multiplier, args.target, timedHit));
			break;
		case FireArguments.eTargetType.AllRowDecay:
			// TODO
		case FireArguments.eTargetType.All:
			CombatManager.Singleton.AddDamageAll(new CombatManager.sDamage(damage, type, multiplier, args.target, timedHit));
			break;
		default:
			Debug.LogError("Unrecognized type.");
			break;
		}

		base.Fire (args);
	}
	
}
