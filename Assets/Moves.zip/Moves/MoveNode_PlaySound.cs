﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class MoveNode_PlaySound : CombatMoveNode
{
	public Vector3 positionRelativeToTarget;

	public AudioClip sound;
	public float volume = 1.0f;

	public override void Fire (FireArguments args)
	{
		base.Fire (args);

		// TODO Might be a good idea to make a static soundmanager to handle this...
		GameObject soundObject = new GameObject();
		// Ensures the audio object is deleted when the move is done.
		soundObject.transform.parent = this.transform;
		AudioSource a = soundObject.AddComponent<AudioSource>();
		a.PlayOneShot(sound, volume);
	}
	
}
