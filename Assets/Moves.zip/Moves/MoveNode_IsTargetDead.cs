﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class MoveNode_IsTargetDead : CombatMoveNode
{
	public List<CombatMoveNode> activateDead = new List<CombatMoveNode>();
	public List<CombatMoveNode> activateAlive = new List<CombatMoveNode>();

	public override void Fire (FireArguments args)
	{
		bool targetsDead = false;
		switch (args.targetType)
		{
		case FireArguments.eTargetType.Single:
			targetsDead = CombatManager.Singleton.IsDead(args.target);
			break;
		case FireArguments.eTargetType.AllRowDecay:
		case FireArguments.eTargetType.All:
			targetsDead = CombatManager.Singleton.IsSideDead(args.target.isPlayer);
			break;
		default:
			Debug.LogError("Unrecognized type.");
			break;
		}

		if (targetsDead)
		{
			foreach (CombatMoveNode c in activateDead)
				c.Fire(args);
		}
		else
		{
			foreach (CombatMoveNode c in activateAlive)
				c.Fire(args);
		}


		base.Fire (args);
	}

	public override void OnDrawGizmos()
	{
		base.OnDrawGizmos ();

		Gizmos.color = Color.magenta;
		foreach (CombatMoveNode c in activateDead)
		{
			Gizmos.DrawLine(this.transform.position+arrowWidth, c.transform.position);
			Gizmos.DrawLine(this.transform.position-arrowWidth, c.transform.position);
		}
		Gizmos.color = Color.cyan;
		foreach (CombatMoveNode c in activateAlive)
		{
			Gizmos.DrawLine(this.transform.position+arrowWidth, c.transform.position);
			Gizmos.DrawLine(this.transform.position-arrowWidth, c.transform.position);
		}
	}
}
