﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class MoveNode_SpawnEffect : CombatMoveNode
{
	public enum ETarget
	{
		actor,
		attackTarget
	};
	
	public ETarget target = ETarget.actor;
	public Vector3 positionRelativeToTarget;
	public GameObject effectToSpawn;

	public override void Fire (FireArguments args)
	{
		base.Fire (args);

		Vector3 spawnLocation = positionRelativeToTarget;
		switch (target)
		{
		case ETarget.actor:
			spawnLocation += args.actor.transform.position;
			break;
		case ETarget.attackTarget:
			spawnLocation += args.target.transform.position;
			break;
		}

		GameObject g = (GameObject) GameObject.Instantiate(effectToSpawn, spawnLocation, Quaternion.identity);
		g.transform.parent = this.transform;

		// TODO Fire children when the effect finishes via delegate.
	}
	
}
