﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class MoveNode_JumpRelativeToTarget : CombatMoveNode
{
	public enum EJumper
	{
		Self,
        Effect
	}
	public EJumper jumper = EJumper.Self;
	public float jumpHeight = 1.0f;
	public AnimationCurve jumpCurve;
	// TODO Rotate base on attacker or defender, so that Z is always positive.
	public Vector3 positionRelativeToTarget;

	private Vector3 startPosition;
	private Vector3 targetPosition;

	public override void Fire (FireArguments args)
	{
		base.Fire (args);

		startPosition = combatData.actor.transform.position;
		targetPosition = combatData.target.transform.position + positionRelativeToTarget;
		if (combatData.actor.isPlayer)
		{
			targetPosition = combatData.target.transform.position + positionRelativeToTarget;
		}
		else
		{
			targetPosition = combatData.target.transform.position + new Vector3(-positionRelativeToTarget.x, positionRelativeToTarget.y, positionRelativeToTarget.z);
		}
	}

	public override void UpdateFrame ()
	{
		float t = 1.0f * framesProgress / frameDuration;
		float height = jumpCurve.Evaluate(t) * jumpHeight;

		combatData.actor.transform.position =
			Vector3.Lerp(startPosition, targetPosition, t) +
			new Vector3(0.0f,height,0.0f);

		base.UpdateFrame();
	}
}
